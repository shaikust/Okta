package com.example.sample;

import org.junit.jupiter.api.Test;

class ApplicationTests {

    @Test
    void contextLoads() {
    }
}
